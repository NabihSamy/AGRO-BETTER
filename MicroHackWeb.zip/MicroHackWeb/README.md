# React with Bun runtime

This is a React project boostrapped with bun.

## Getting Started
this is a project management app i made to learn React 


### Cloning the repo

```sh
bun create react ./app
```

### Development

First, run the development server.

```
bun dev
```

Open http://localhost:3000 with your browser to see the result.

You can start editing the page by modifying src/App.jsx. The page auto-updates as you edit the file.

