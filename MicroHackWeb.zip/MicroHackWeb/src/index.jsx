import * as React from "react";
import ReactDOM from "react-dom";
import "./items/css/index.css";


import MyApp from "./items/MyApp"

ReactDOM.render(
  <React.StrictMode>

  <MyApp />
    
  </React.StrictMode>,
  document.getElementById("root")
);
