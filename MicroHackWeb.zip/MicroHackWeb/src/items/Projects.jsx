import * as React from "react";
import {useRef, useEffect,useState} from 'react';
import { TailSpin,Oval } from "react-loader-spinner";
import "./css/Projects.css";
import {URL_projects} from './URLS'
import "./css/Utils.css"
import iconX from './assets/iconX.png'
import loupe from './assets/109859.png'



function Projects({setProject,deleteProj,setTerrain}){
    const [NewProj,setNewProj] = useState(null)
    const [ErrBox, setErrBox] = useState("")

    return(
        <>
        <div className="projects">
            <div className="title">
                <div className="text">Users</div>
                <input type="checkbox" name="add" id="add" onClick={()=>setErrBox("")}/>
                <label className="add" htmlFor="add" >
                    <svg className="addLogo" width="18px" height="18px" fill="ffffff">
                        <path d="M16.507 7.423H10.733V1.654C10.733.74 9.996 0 9.083 0c-.913 0-1.65.74-1.65 1.654v5.773H1.656c-.913 0-1.656.74-1.655 1.654 0 .456.184 .875.483 1.174.299 .3.712 .489 1.168.489h5.781V16.508c0 .457.181 .87.48 1.169.299 .299.711 .484 1.168.484 .913 0 1.652-.74 1.652-1.653V10.743h5.774c.913 0 1.654-.747 1.653-1.66C18.16 8.17 17.419 7.423 16.507 7.423z"></path>
                    </svg>
                </label>
                <FormProject setNewProj={setNewProj} setErrBox={setErrBox} ErrBox={ErrBox}/>
            </div>
            <div className="scroller">
                <div className="list">
                    <ProjectList setProject={setProject} setTerrain={setTerrain} NewProj={NewProj} deleteProj={deleteProj}/>
                </div>
            </div>
        </div>
        </>
    )
}

function FormProject({setNewProj,ErrBox,setErrBox}){
        //set up mindate for input

        function verifyData(refText){
            if(refText.current.value === ""){
                return "Le titre ne peut etre vide"
            }
            return true 
        }
        const refText = useRef(null);
        
        const [LoadingNewprj, setLoadingNewprj] = useState(false)



        useEffect(async () => {
            if(LoadingNewprj===true){
                let dataTest = verifyData(refText)
                if(dataTest === true){
                    setErrBox("")

                    var data = new FormData()
                        data.append("title",refText.current)

                    let response = await fetch(URL_projects,{'method':"POST",'body':data}).catch((err)=>{setErrBox("No network");setLoadingNewprj(false)})

                    if(response.ok){
                        data = await response.json()
                        let proj = {
                            "id":data.id,
                            "title":refText.current.value,
                        }
                        setNewProj(proj)
                    }else{
                        setErrBox("verifier les donnes et ressayer ultérieurement")
                    }
                }else{
                    setErrBox(dataTest)
                }
                setLoadingNewprj(false)
            }
        }, [LoadingNewprj])
        

    return(
        <div className="newProjContainer">
        <div className="title">
            New user
        </div>
        <div className="newProj">
            <input ref={refText} className="newPinput" type="text" name="newProjTitle" id="newProjTitle" placeholder="Name" />
            <div id="newPrjErreur">{ErrBox}</div>
            
            <div className="control">
                <LoaderButton LoadingNewprj={LoadingNewprj} setLoadingNewprj={setLoadingNewprj}/>
                <label htmlFor="add" onClick={()=>setErrBox("")} ><img src={iconX} alt="" srcSet="" /></label>
            </div>
        </div>

    </div>
    )
}

function LoaderButton({LoadingNewprj,setLoadingNewprj}){
    if(LoadingNewprj){
        return(
            <button value="Add" > 
                <div className="loaderCentrer">
                    <Oval
                    height={20}
                    width={20}
                    color="#000000"
                    wrapperStyle={{}}
                    wrapperClass=""
                    visible={true}
                    ariaLabel='oval-loading'
                    secondaryColor="#555555"
                    strokeWidth={5}
                    strokeWidthSecondary={5}
                    />
                </div>
            </button>
        )
    }else{
        return(
            <button value="Add" onClick={()=>setLoadingNewprj(true)}> Add </button>
        )
    }
}

function ProjectList({setProject,NewProj,deleteProj,setTerrain}){
    var colors = ["#4700D8","#9900F0","#F900BF","#FF85B3","#5E11D4","#D164BD","#A343C6","#8C33CB","#7522CF"]
    
    //fetching projects
    const [Projects,setProjects] = useState(null)
    const [Temp,setTemp] = useState(null)
    useEffect(() => {
        if(Projects === null){
            fetchProjects(setProjects).catch(error => {setProjects(404)})
        }
    }, [Projects])
    useEffect(async () => {
        let temp = []

        if(deleteProj != null){

                Projects.map((task)=>{
                    if(task.id != deleteProj){
                      temp.push(task)  
                    }})

                setProjects(temp) 
                setTemp(temp)
            }
        }
    , [deleteProj])
    useEffect(() => {
        if(NewProj != null){
            let t = []
            Projects.map((prj)=>{
                t.push(prj)
            }
            )
            t.push(NewProj)
            setProjects(t)
            setTemp(t)
        }
  
      }, [NewProj])
    
      async function fetchProjects(setProjects){
        const response = await fetch(URL_projects)
        if (!response.ok) {
            const message = `An error has occured: ${response.status}`;
            setProjects(404)
            throw new Error(message);
        }
    
        const Projects = await response.json()
        setProjects(Projects)
        setTemp(Projects)
    }

    const SearchVal = (event) => {
        console.log(event.target.value);
        let temp = []
        
        Projects.forEach(item => {
          if(item.title.toLowerCase().includes(event.target.value.toLowerCase())){temp.push(item)}})
          setTemp(temp)
    }


    //return componement
    if(Temp === null ){
        return (
            <div className="loaderCentrer">
                <TailSpin
                height="80"
                width="80"
                color="#4fa94d"
                ariaLabel="tail-spin-loading"
                radius="1"
                wrapperStyle={{}}
                wrapperClass=""
                visible={true}
                />
            </div>
        )
    }else if(Temp === 404){
        return(
            <div className="loadingError">
                Rechargez la page
            </div>
        )
    }else{
        return (
            <>
            <div className="center">
                <div className="search">
                    <input type="text" name="Search" id="Search" onChange={SearchVal} placeholder="Recherche"/>
                    <div className='center'><image src={loupe}></image></div>
                </div>
            </div> 
            {
            Temp.map((task)=>(
                <div className="Project" key={task.id} onClick={() => {setProject(task.id);setTerrain(task.id)}}>
                    <div className="box" style={{backgroundColor: colors[task.id % colors.length]}}> </div>
                    <div className="title">{task.title}</div>
                    <div className="deadline"></div>
                </div>
            ))}
            </>
        )
    }

}
export default Projects

