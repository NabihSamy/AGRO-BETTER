
export const URL_tasks="https://my-json-server.typicode.com/kcmki/ReactTodos/Todos"
export const URL_projects="https://my-json-server.typicode.com/kcmki/ReactTodos/Projects"
